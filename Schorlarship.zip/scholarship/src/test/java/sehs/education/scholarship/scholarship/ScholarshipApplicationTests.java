package sehs.education.scholarship.scholarship;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScholarshipApplicationTests {

	@Test
	void contextLoads() {
	}

}
